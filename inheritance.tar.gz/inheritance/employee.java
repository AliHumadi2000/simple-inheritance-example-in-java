package one;
class Employee extends Person
	{
	double salary;
	String job;
	public Employee(){}
	public Employee(String n,int a,String ad,double s,String j)
		{
		super(n,a,ad);
		salary=s;
		job=j;
		}
	public void setSalary(double salary)
		{
		this.salary=salary;
		}
	public void setJob(String job)
		{
		this.job=job;
		}
	public double getSalary()
		{
		return salary;
		}
	public String getJob()
		{
		return job;
		}
	
		
	}