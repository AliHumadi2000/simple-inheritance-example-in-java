package one;
class Student extends Person
	{
	int study_level;
	String specilization;
	double gpa;
	public Student(){}
	public Student(String n,int a,String add,int std,String spe,double c)
		{
		super(n,a,add);
		study_level=std;
		specilization=spe;
		gpa=c;
		}
	public void setStudyLevel(int study_level)
		{
		this.study_level=study_level;
		}
	public void setSpecilization(String specilization)
		{
		this.specilization=specilization;
		}
	public void setGpa(double gpa)
		{
		this.gpa=gpa;
		}
	public int getStudyLevel()
		{
		return study_level;
		}
	public String getSpecilization()
		{
		return specilization;
		}
	public double getGpa()
		{
		return gpa;
		}
		
	}