package one;
class Person
	{
	String name;
	int age;
	String add;
	public Person(){}
	public Person(String n,int a,String d)
		{
		name=n;
		age=a;
		add=d;
		}
	public void printdata()
		{
		System.out.println("Name is "+name);
		System.out.println("age is "+age);
		System.out.println("adderess "+add);
		}
	public void setName(String na)
		{
		name=na;
		}
	public void setAge(int a)
		{
		age=a;
		}
	public void setAdd(String ad)
		{
		add=ad;
		}
	public String getName()
		{
		return name;
		}
	public int getAge()
		{
		return age;
		}
	public String getAdd()
		{
		return add;
		}
}