package one;
class Mine
	{
	public static void main(String[]args)
		{
		
		Student obj=new Student("Ali",23,"Yemen",3,"Eng",8.4);
		Employee object=new Employee("jak",30,"UK",2500.33,"Doctor");
		
		
		object.printdata();
		System.out.println("Salary is "+object.getSalary());
		System.out.println("job is "+object.getJob());
		obj.printdata();
		System.out.println("studylvel is " +obj.getStudyLevel());
		
		}
	}